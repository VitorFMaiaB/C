#include <stdio.h>
float d(float matriz[][3]);
float dx(float matriz[][3]);
float dy(float matriz[][3]);
void main(){
    float matriz[2][3],matrix[2][3],det[3];
    for(int i=0 ; i<2 ; i++){                   //pega a matriz
        for(int j=0 ; j<3 ; j++){
            scanf("%f", &matriz[i][j]);
        }
    }
    det[0]=d(matriz);
    det[1]=dx(matriz);
    det[2]=dy(matriz);
   
    if(det[0]==0){                              //se det[0] for igual a zero o sistema só pode ser impossível ou indeterminado
        if(det[1]==0 && det[2]==0){             //apenas se det[1] e det[2] forem 0 o sistema será indeterminado   
            printf("Sistema indeterminado");    
        }else{
            printf("Sistema impossível");
        }
    }else{
        printf("X=%f,Y=%f",det[1]/det[0],det[2]/det[0]);
    }
}
float dx(float matriz[][3]){
    
    float det = matriz[0][2]*matriz[1][1]-matriz[0][1]*matriz[1][2];
    
    return det;
}
float dy(float matriz[][3]){
    
    float det = matriz[0][0]*matriz[1][2]-matriz[0][2]*matriz[1][0];
    
    return det;
}
float d(float matriz[][3]){
    
    float det = matriz[0][0]*matriz[1][1]-matriz[0][1]*matriz[1][0];
    
    return det;
}