#include <stdio.h>
#include <stdlib.h>

void levet(int *, int);
int maxvet(int *, int);
void intercal(int *, int, int, int, int, int *, int *, int *);
void mergerec(int *, int, int, int *, int *, int *);
void merge(int *, int, int*, int*);
void insertion(int *, int, int*, int*);

int main(){
    int Q, *N, *vet, *vet2, *trocas, *comp;
    scanf("%d", &Q); //leitura do nÃºmero de vetores
    N=(int*)malloc(Q*sizeof(int)); //alocaÃ§Ã£o
    trocas=(int*)malloc(sizeof(int));
    comp=(int*)malloc(sizeof(int));
    if(N==NULL||trocas==NULL||comp==NULL){
        printf("deu ruim\n");
        exit(-1);
    }
    levet(N, Q); //leitura do nÃºmero de elementos de cada vetor
    vet=(int*)malloc(sizeof(int)*maxvet(N ,Q));//alocaÃ§Ã£o
    vet2=(int*)malloc(sizeof(int)*maxvet(N ,Q));
    if(vet==NULL||vet2==NULL){
        printf("deu ruim\n");
        exit(-1);
    }

    for(int i=0; i<Q; i++){
        levet(vet, N[i]);
        for(int j = 0; j < N[i]; j++){
            vet2[j] = vet[j];
        }
        insertion(vet, N[i], trocas, comp);
        printf("I %d %d %d\n", N[i], trocas[0], comp[0]);
        merge(vet2, N[i], trocas, comp);
        printf("M %d %d %d\n", N[i], trocas[0], comp[0]);
    }

    return 0;
}

void levet(int *vet, int n){
    for(int i=0;i<n;i++){
        scanf("%d", &vet[i]);
    }
}

int maxvet(int *num, int q){
    int aux=num[0];
    for(int i=1; i<q;i++){
        if(aux<num[i]){
            aux=num[i];
        }
    }
    return aux;
}

void intercal(int *vet, int inicio1, int fim1, int inicio2, int fim2, int *aux, int *troc, int *comp){
    int i1=inicio1;
    int i2=inicio2;
    int j=0;
    while(i1<=fim1&&i2<=fim2){
        comp[0]++;
        if(vet[i1]>vet[i2]){
            troc[0]++;
            aux[j]=vet[i2];
            i2++;
            j++;
        }
        else{
            troc[0]++;
            aux[j]=vet[i1];
            i1++;
            j++;
        }
    }
    while(i1<=fim1){
        troc[0]++;
        aux[j]=vet[i1];
        i1++;
        j++;
    }
    while(i2<=fim2){
        troc[0]++;
        aux[j]=vet[i2];
        i2++;
        j++;
    }
    for(int i=0; i<=fim2-inicio1; i++){
        troc[0]++;
        vet[inicio1+i]=aux[i];
    }
}

void mergerec(int *vet, int inicio, int fim, int *aux, int *troc, int *comp){
    if(inicio>=fim){
        return;//base
    }
    int m=(fim+inicio)/2;
    mergerec(vet, inicio, m, aux, troc, comp);
    mergerec(vet, m+1, fim, aux, troc, comp);
    intercal(vet, inicio, m, m+1, fim, aux, troc, comp);
}

void merge(int *vet, int n, int *troc, int *comp){
    int *aux=(int*)malloc(sizeof(int)*n);
    if(aux==NULL){
        printf("Deu ruim\n");
        exit(-1);
    }
    troc[0]=0;
    comp[0]=0;
    mergerec(vet, 0, n-1, aux, troc, comp);
    free(aux);
}

void insertion(int *vet, int n, int *troc, int *comp){
    troc[0]=0;
    comp[0]=0;
    int aux, j;
    for(int i = 1; i < n; i++ ){
        aux = vet[i];
        for(j = i; aux < vet[j-1] && j-1 >= 0; j--){
            vet[j] = vet[j-1];
            
            comp[0]++;
            troc[0]++;
            
        }vet[j] = aux;
        troc[0] += 2;
        if(j-1 >= 0){
            comp[0]++;
        }
    }

}
