
#include <stdio.h>
#include <stdlib.h>

void radix_Sort (unsigned int *vet, int size, int exp, unsigned int n_keys) {
    
  int* keys_size = (int *) calloc (n_keys, sizeof(int));
  int* temp_vet = (int *) calloc (size, sizeof(int));
  int max = 0;
  for(int i = 0; i < size; i++)
  {
    if(vet[i] > max)
    {
      max = vet[i];
    }
  }
  for(int j = 0; (1<<j) < max + exp; j+=exp)
   {
    
    

    int n = n_keys-1;
    for(int i = 0; i < size; i++)
    {
      keys_size[((vet[i]>>j)&n)+1]++;
    }
    for (int i = 0; i < n_keys-1; i++){
      keys_size[i+1] += keys_size[i];
    }

    for(int i = 0; i < size; i++)
    {
      temp_vet[keys_size[((vet[i]>>j)&n)]] = vet[i];
      (keys_size[((vet[i]>>j)&n)])++;
    }

    for (int i = 0; i < size; i++) {
      vet[i] = temp_vet[i];
    }

    for (int i = 0; i < size; i++) {
      printf ("%u ", vet[i]);
    }
    printf("\n");
    for(int i = 0; i < n_keys; i++){
        keys_size[i] = 0;
    }
  }
  
  
}


int main () {
  int exp;
  int n_vet;

  scanf ("%d", &exp);
  scanf ("%d", &n_vet);
  
  unsigned int n_keys = (1<<exp);
  unsigned int *vet = (unsigned int *) calloc (n_vet, sizeof(unsigned int));

  for (int i = 0; i < n_vet; i++)
  {
    scanf ("%u", &vet[i]);
  }
  radix_Sort(vet, n_vet, exp, n_keys);
}