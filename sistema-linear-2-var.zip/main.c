#include <stdio.h>

void main(){
    float matriz[2][3],matrix[2][3],det[3];
    for(int i=0 ; i<2 ; i++){                   //pega a matriz
        for(int j=0 ; j<3 ; j++){
            scanf("%f", &matriz[i][j]);
        }
    }for(int i=0;i<3;i++){                      //iguala uma segunda matriz à primeira
        for(int j=0 ; j<2 ; j++){
            for(int k=0 ; k<3 ; k++){
                matrix[j][k]=matriz[j][k];
            }
        }       
        matrix[0][(2+i)%3]=matriz[0][2];        //modifica os valores dessa segunda matriz para resolver o sistema 
        matrix[1][(2+i)%3]=matriz[1][2];        //usando regra de kramer
        det[i]= matrix[0][0]*matrix[1][1]-matrix[0][1]*matrix[1][0]; // calcula as determinantes
    }

    if(det[0]==0){                              //se det[0] for igual a zero o sistema só pode ser impossível ou indeterminado
        if(det[1]==0 && det[2]==0){             //apenas se det[1] e det[2] forem 0 o sistema será indeterminado   
            printf("Sistema indeterminado");    
        }else{
            printf("Sistema impossível");
        }
    }else{
        printf("X=%f,Y=%f",det[1]/det[0],det[2]/det[0]);
    }
}