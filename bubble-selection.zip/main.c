/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void selecao(int n, int* v){
    int x, troca;
    for(int i = 0;i < n ; i++){
        x = i;
        for(int j = i+1; j < n ; j++){
            printf("C %d %d\n", x, j);
            if(v[x] > v[j]){
                x=j;
            }
        }if(x != i) printf("T %d %d\n", i, x);
        troca = v[x];
        v[x] = v[i];
        v[i] = troca;
        
    }
}
void bolha(int n, int* v){
    int troca, ultTroca;
    for(; 0 < n; n = ultTroca){
        ultTroca = 0;
        for(int i =0; i < n-1; i++){
            printf("C %d %d\n", i, i+1);
            if(v[i] > v[i+1]){
                printf("T %d %d\n", i, i+1);
                troca = v[i];
                v[i] = v[i+1];
                v[i+1] = troca;
                ultTroca = i + 1;
            }
            
        }
    }
}

int main(){
    int q;
    int* v;
    char met[10];
    scanf("%s", met);
    scanf("%d", &q);

    v = malloc(q * sizeof(long int));
    for(int i=0; i < q; i++){
       scanf("%d",&v[i]);
    }v[q]='\0';
    if(strcmp (met, "bolha") == 0){
        bolha(q, v);
    }
    if(strcmp (met, "selecao") == 0){
        selecao(q,v);
    }
    for(int i=0;i<q;i++){
         printf("%d ",v[i]);
     }free(v);
     return 0;
}