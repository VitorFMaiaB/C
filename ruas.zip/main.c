#include <stdio.h>
#include <stdlib.h>

int achaMax(int **ruas, int in, int fin, int index, int n){
    if(in == fin){
        return ruas[index][2];
    }
    if(ruas[in][4] != 0){
        return ruas[in][3] + ruas[index][2];
    }
    for(int i = 0; i < n; i++){
        if(ruas[i][0] == in){
            int num = achaMax(ruas, ruas[i][1], fin, i, n);
            if(num > ruas[in][3]){
                ruas[in][3] = num;
            }
            
        }
    }
    ruas[in][4]++;
    return ruas[in][3] + ruas[index][2];
}


int main(){
    int x,y,fin;
    scanf("%d %d", &x, &y);
    int n = (x*(y-1)+(x-1)*y);
    int **ruas= malloc(sizeof(int*)*n);
    for(int i = 0; i < n; i++){
        ruas[i] = malloc(sizeof(int)*5);
        for(int j = 0; j < 3; j++){
            scanf("%d", &ruas[i][j]);
        }ruas[i][3] = -1;
        ruas[i][4] = 0;
    }fin = x*y-1;
    printf("%d",achaMax(ruas, 0, fin, 0, n) - ruas[0][2] );

    return 0;
}

