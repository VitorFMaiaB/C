#include <stdio.h>
#include <stdlib.h>
void hashadd(int* vet, int num, int tam){
    
    int i = 0;
    int end = (num+i)%tam;
    for(;vet[end] != num;i++){
        if(vet[end] == '\0'){
            vet[end] = num;
            return;
        }
        end = (num+i)%tam;
    }
}

int hash(int* vet, int num, int tam){
    
    int i = 0;
    int end = (num+i)%tam;
    for(; vet[end] != '\0' && i < tam;i++){
        
        if(vet[end] == num){
            return end;
        }
        end = (num+i)%tam;

    }return -1;
    
}

int main(){
    int m, n, r, b, temp, end;
    scanf("%d",&m);
    int* vet = malloc(m*sizeof(int));
    for(int i = 0; i < m; i++){
        vet[i]='\0';
    }
    scanf("%d",&n);
    for(int i = 0; i < n; i++){
        scanf("%d",&temp);
        hashadd(vet, temp, m);
    }
    scanf("%d",&r);
    for(int i = 0; i < r; i++){
        scanf("%d",&temp);
        end = hash(vet, temp, m);
        if(end != -1){    
            vet[end] = -1;
        }    
    }
    scanf("%d",&b);
    for(int i = 0; i < b; i++){
        scanf("%d",&temp);
        end = hash(vet, temp, m);
        printf("%d ",end);
    }

}
