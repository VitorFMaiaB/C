#include <stdio.h>


void main(){
    int matriz[3][3],detL,det=0;
    for(int i=0 ; i<3 ; i++){
        for(int j=0 ; j<3 ; j++){
            scanf("%d", &matriz[i][j]);
        }
    }
    
    for(int i=0;i<3;i++){
        detL=matriz[0][i]*matriz[1][(i+1)%3]*matriz[2][(i+2)%3]-matriz[0][(i+2)%3]*matriz[1][(i+1)%3]*matriz[2][i];
        det+=detL;
    }printf("%d",det);
}