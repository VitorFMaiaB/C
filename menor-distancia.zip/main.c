#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#define MAX 1000
float dist(float **pts, int i, int j){
    return sqrt(pow((pts[i][0] - pts[j][0]),2)+pow((pts[i][1]-pts[j][1]),2));
}

float menDist(float **pts, int in, int fim){
    
    if(in >= fim){
        return MAX;
    }else if(in + 1 == fim){
        return dist(pts, in, fim);
    }float dMen;
    int m = (in + fim)/2;
    //float dMen = MAX;
    float d1 = menDist(pts, in, m);
    float d2 = menDist(pts, m+1, fim);
    if(d1 < d2){
        dMen = d1;
    }else{ 
        dMen = d2;
    
    }for(int i = in; i < fim ; i++){
        if( dMen <= pts[i][0] &&  dMen >= pts[i][0]){
            for(int j = i+1; j < fim ; j++){
                if( dMen <= pts[j][0] &&  dMen >= pts[j][0]){
                    float d3 = dist(pts, i, j);
                    if(d3 < dMen){
                        dMen = d3;
                    }
                }    
            }
            
        }
    }return dMen;
    
    
    
}


void heapdown (int n, int org, int q, float** pts){
    float num;
    if(2*n+1<=q-org-1){
        
        if(2*n+2<=q-org-1 && (pts[n][0]<pts[2*n+1][0]||(pts[n][0]<pts[2*n+2][0]))){
            if(2*n+2>q-org-1 || pts[2*n+1][0]>pts[2*n+2][0]){
                num=pts[n][0];
                pts[n][0]=pts[2*n+1][0];
                pts[2*n+1][0]=num;
                num=pts[n][1];
                pts[n][1]=pts[2*n+1][1];
                pts[2*n+1][1]=num;
                n=2*n+1;
                heapdown(n, org, q, pts);
            }else{
                num=pts[n][0];
                pts[n][0]=pts[2*n+2][0];
                pts[2*n+2][0]=num;
                num=pts[n][1];
                pts[n][1]=pts[2*n+2][1];
                pts[2*n+2][1]=num;
                n=2*n+2;
                heapdown(n, org, q, pts);
            }
        }   
        
    }
}


void heap(float **pts, int q){

    float num;
    int org = 0;
    
    for(int i=q/2;i>=0;i--){
        heapdown(i,org,q,pts);
    }
    while(org<q){
        num=pts[0][0];
        pts[0][0]=pts[q-org-1][0];
        pts[q-org-1][0]=num;
        num=pts[0][1];
        pts[0][1]=pts[q-org-1][1];
        pts[q-org-1][1]=num;
        org++;
        heapdown(0,org,q,pts);
    }


}

int main(){
    int x;
    scanf("%d", &x);
    float **pts = malloc(sizeof(float*)*x);
    for(int i = 0; i < x; i++){
        pts[i] = malloc(sizeof(float)*2);
        scanf("%f%f",&pts[i][0], &pts[i][1]);
    }
    heap(pts, x);
    
    //printf("DistÃ¢ncia entre (%6f,%6f) e (%6f e %6f) = %.6f\n",pts[0][0],pts[0][1],pts[1][0],pts[1][1], dist(pts, 0, 1));
    /*for(int i=0;i<x;i++){
         printf("%f,%f\n ",pts[i][0], pts[i][1]);
     }*/
    
    printf("%.6f", menDist(pts, 0, x));

}




