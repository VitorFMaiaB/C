/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main(){
    int x, c, i;
    int dez = 10;
    int e = 0;
    scanf("%d",&x);
    x=x*x;
    while(x%dez!=x){
        e++;
        dez=dez*10;
    }int res[e+1];
    for(dez=10,i=0;x!=;i++){
        for(c=0;x%dez!=0;c++){
            x=x-(dez/10);
        }res[i]=c;
        dez=dez*10;
    }while(e>=0){
        switch(res[e]){
            case 0:
            printf("ZERO ");
            break;
            case 1:
            printf("UM ");
            break;
            case 2:
            printf("DOIS ");
            break;
            case 3:
            printf("TRES ");
            break;
            case 4:
            printf("QUATRO ");
            break;
            case 5:
            printf("CINCO ");
            break;
            case 6:
            printf("SEIS ");
            break;
            case 7:
            printf("SETE ");
            break;
            case 8:
            printf("OITO ");
            break;
            case 9:
            printf("NOVE ");
            break;
        }
        e--;
    }
    return 0;
}
