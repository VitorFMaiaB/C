#include <stdio.h>

double calcFat(int nFat){
    double fat=1;
    while(1<nFat){
        fat = fat*1/nFat;
        nFat--;
    }
    return fat;
}

void calculaSeno(double x, int c){
    double xis, res=0, fat=1;
    int i=0, nFat=1, neg=1;
    xis=x;
    while (i<c){
        fat = calcFat(nFat);
        res = res + fat*neg*x;
        x=x*xis*xis;
        nFat += 2;
        neg=-neg;
        i++;
    }printf("%.6lf",res);
}
void main(){
    double x;
    int c;
    scanf("%lf %d",&x,&c);
    calculaSeno(x,c);
}

