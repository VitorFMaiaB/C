#include <stdio.h>
void main(){
    float x, xis, res=0;
    int i=1, fat=1, nFat=2, neg=1, c;
    scanf("%f%d",&x,&c);
    xis=x;
    res=neg*x/fat;
    x=x*xis;
    fat = fat*nFat*(nFat+1);
    nFat += 2;
    neg=-neg;
    if(c==1){
       printf("%f",res); 
    }else{
        while (i<c){
            res= res + neg*x/fat;
            x=x*xis*xis;
            fat = fat*nFat*(nFat+1);
            nFat += 2;
            neg=-neg;
            i++;
        }printf("%f",res);
    }
}