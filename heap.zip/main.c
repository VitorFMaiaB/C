#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void heapdown (int n, int org, int q, int* v){
    int num;
    if(2*n+1<=q-org-1){
        
        if(v[n]<v[2*n+1]||(v[n]<v[2*n+2] && 2*n+2<=q-org-1)){
            if(v[2*n+1]>v[2*n+2]||2*n+2>q-org-1){
                num=v[n];
                v[n]=v[2*n+1];
                v[2*n+1]=num;
                n=2*n+1;
                heapdown(n, org, q, v);
            }else{
                num=v[n];
                v[n]=v[2*n+2];
                v[2*n+2]=num;
                n=2*n+2;
                heapdown(n, org, q, v);
            }
        }   
        
    }
}


void main(){
    int n, org, num, q;
    int* v;
    org=0;
    scanf("%d",&q);

    v = malloc(q * sizeof(int));
    for(int i=0;i<q;i++){
        v[i]= rand()%100;
        //scanf("%d",&v[i]);
    }v[q]='\0';
    
    
    for(int i=q/2;i>=0;i--){
        heapdown(i,org,q,v);
        //for(int j=0;j<q;j++){
        // printf("%d ",v[j]);
     //}printf("\n");
    }
    while(org<q){
        num=v[0];
        v[0]=v[q-org-1];
        v[q-org-1]=num;
        org++;
        heapdown(0,org,q,v);
    }
    for(int i=0;i<q;i++){
         printf("%d ",v[i]);
     }
}



