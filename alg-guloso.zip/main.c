
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX 200

int overlap (char* str1, char* str2){
    
    int charsEq = 0;
    for(int i = 0; i < strlen(str1);i++){
        if(str2[charsEq] == str1[i]){
            charsEq++;
        }else{
            charsEq = 0;
            if(str2[charsEq] == str1[i]){
            charsEq++;
        }
            
            
        }
        if(charsEq == strlen(str2)){
            return charsEq;
        }
    }
    return charsEq;
}

char* juntaStr(char **dna, int n){
    if (n == 1){
        return dna[0];
    }
    int iMax = 0, jMax = 1, olMax = 0;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            if (i != j){
                int ol = overlap(dna[i], dna[j]);
                if (ol > olMax){
                    iMax = i;
                    jMax = j;
                    olMax = ol;
                }
                //printf("(%d,%d) Overlap: %d\n",i,j,ol);  
            }
        }
    }
    strcat(dna[iMax],dna[jMax]+olMax);
    char **nDna = malloc(sizeof(char*)*n-1);
    for(int i = 0; i < n; i++){
        nDna[i] = malloc(sizeof(char)*MAX);
    }nDna[0] = dna[iMax];
    int i = 1;
    for(int j = 0; j < n; j++){
        if(j != iMax && j != jMax){
            nDna[i] = dna[j];
            i++;
        }
    }//printf("%s\n",nDna[0]);
    
    return juntaStr(nDna,n-1);
}

int main(){
    int n; 
    scanf("%d",&n);
    char **dna = malloc(sizeof(char*)*n);
    for(int i = 0; i < n; i++){
        dna[i] = malloc(sizeof(char)*MAX);
        scanf("%s",dna[i]);
    }
    printf("%s",juntaStr(dna,n));
    return 0;
    

    
    

}

