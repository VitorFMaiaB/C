#include <stdio.h>

int main(){
    int matriz[5][5],jog,count,res=0;
    scanf("%d",&jog);
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            scanf("%d",&matriz[i][j]);
        }
    }
    for(int i=0;i<5;i++){
        for(int j=0;j<3;j++){
            for(int k=0;k<3;k++){
                if(matriz[j+k][i]==jog){
                    count=count+1;
                }else if(matriz[j+k][i]!=0){
                    count= count-2;
                }
            }if(count==2){
                res=res+50;
            }else if(count==1){
                res=res+10;
            }count=0;
        }
    }printf("%d",res);
    return 0;    
}




