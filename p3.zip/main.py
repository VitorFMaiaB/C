# Vítor Fonseca Maia Batista, 11800667, Engenharia Elétrica

class itens(): 
    
    def __init__(self, descr, val, peso, qtd):
        'constrói cada iteração da classe "items" com uma descrição, valor, peso e quantidade que serão escolhidos pelo usuário'
        self.descr = descr
        self.val = val
        self.peso = peso
        self.qtd = qtd
    def __str__(self):
        'retorna a string que será printada'
        return '%s (%s, %s)' %(self.descr, str(round(self.val,4)) , str(round(self.peso,4)))
    
nItens= int(input()) #pega os inputs do usuário e inicializa valores
capacidade= float(input())
cont= 0
pesoAtual= 0.0
valTotal=0.0
lsItens=[]


while cont < nItens:
    item=itens(input(),float(input()),float(input()),int(input()))
    lsItens.append(item)
    cont+=1
metodo = input()

    
    
print('== itens disponiveis ==')
for item in lsItens:
    print(item.qtd, item)


if metodo == "peso": #organiza a lista de acordo com o método escolhido
    lsItens.sort(key= lambda item: [item.peso,-(item.val),item.descr])
if metodo == "valor": 
    lsItens.sort(key= lambda item: [-(item.val),item.peso,item.descr] )
if metodo == "densidade": 
    lsItens.sort(key= lambda item: [-(item.val/item.peso),-(item.val),item.peso])
    
    
print('== adicionando itens ==') #adiciona os itens um a um até acabarem os itens ou não for possível adicionar o próximo item por excesso de peso
for item in lsItens:
    cont=0
    while cont < item.qtd and pesoAtual + item.peso <= capacidade:
        print('+', item)
        pesoAtual += item.peso
        valTotal += item.val 
        cont+=1
     
        
print('Capacidade utilizada = %.4f' %(pesoAtual))
print('Capacidade nao utilizada = %.4f' %(capacidade-pesoAtual))
print('Valor total = %.4f' %(valTotal))
    