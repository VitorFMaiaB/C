opc=-1
Pedidos=[]
Entregues=[]
i,j,NaoEnt,Ent=0,0,0,0

while opc!=0:
    opc=int( input() )
    if opc==1:
        NovoPedido=( input(),int( input() ),float( input() ) )
        Pedidos.append(NovoPedido)
        i+=1
    elif opc==2:
        c=0
        if i>0:
            print("Pedidos na fila:")
            while c<i:
                print("-",Pedidos[c][1],"x",Pedidos[c][0] )
                c+=1
    elif opc==3:
        if i>0:
            Entregador=Pedidos.pop(0)
            Entregues.append(Entregador)
            print("> Entregue:",Entregues[j][1],"x",Entregues[j][0])
            j+=1
            i-=1
    elif opc==4:
        while i>0:
            Entregador=Pedidos.pop(0)
            Entregues.append(Entregador)
            print("> Entregue:",Entregues[j][1],"x",Entregues[j][0])
            j+=1
            i-=1
if i>0:
    c=0
    while c<i:
        NaoEnt += Pedidos[c][1]*Pedidos[c][2]
        c+=1
    print("Pedidos não entregues: R$ %.2f" % (NaoEnt) )
c=0
while c<j:
    Ent+= Entregues[c][1]*Entregues[c][2]
    c+=1
print("Vendas: R$ %.2f" % (Ent) )
