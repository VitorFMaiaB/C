# Vítor Fonseca Maia Batista N.USP 11800667
# Introducao a Programacao para Engenharias - 2021
x = float(input())
um,dois,cin,dez,vin,cinco,cem,qui=0,0,0,0,0,0,0,0
if x!=int(x):
    print('Valor inválido: digite um valor inteiro, essa máquina não possui moedas')
elif not 0<x<=5000:
    print('Valor inválido: saques permitidos entre 1 e 5000 reais')
else:
    opc=int(input())
    if opc==1:
        if x-500>=0:
            while x-500>=0:
               qui+=1
               x=x-500
            print('500:',qui)
        if x-100>=0:
            while x-100>=0:
                cem+=1
                x=x-100
            print('100:',cem)
        if x-50>=0:
            while x-50>=0:
                cin+=1
                x=x-50
            print('50:',cin)
        if x-20>=0:
            while x-20>=0:
                vin+=1
                x=x-20
            print('20:',vin)
        if x-10>=0:
            while x-10>=0:
                dez+=1
                x=x-10
            print('10:',dez)
        if x-5>=0:
            while x-5>=0:
                cinco+=1
                x=x-5
            print('5:',cinco)
        if x-2>=0:
            while x-2>=0:
                dois+=1
                x=x-2
            print('2:',dois)
        if x-1>=0:
            while x-1>=0:
                um+=1
                x=x-1
            print('1:',um)
    elif opc==2:
        if x-20>=0:
            while x-20>=0:
                vin+=1
                x=x-20
            print('20:',vin)
        if x-10>=0:
            while x-10>=0:
                dez+=1
                x=x-10
            print('10:',dez)
        if x-5>=0:
            while x-5>=0:
                cinco+=1
                x=x-5
            print('5:',cinco)
        if x-2>=0:
            while x-2>=0:
                dois+=1
                x=x-2
            print('2:',dois)
        if x-1>=0:
            while x-1>=0:
                um+=1
                x=x-1
            print('1:',um)

        