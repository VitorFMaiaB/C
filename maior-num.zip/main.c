
#include <stdio.h>

void main(){
    int x,y,res;
    scanf("%d%d",&x,&y);
    if(x>y){
        res=x;
    }else{
        res=y;
    }
    printf("%d",res);
}