# Vítor Fonseca Maia Batista, 11800667, Engenharia Elétrica
def imprimeTurnos(turnos):
    turnos.sort() #ordena a lista em ordem alfabética de acordo com o ome do produto
    print('---------------')
    for turno in turnos: #para cada elemento em turnos a função deverá imprimir o código, quantidade e horas
        print(turno[0],' - qtd:',turno[1],' - turno:',turno[2],' horas')
    print('---------------')
    
    
def prdtsDia(turnos,dia,prdts):
    conjPrdts=set({})#cria o conjunto para que possam ser adicionados elementos a ele
    for turno in turnos:#para cada elemento em turnos se o dia coincidir com o dia escolhido, o nome do produto é adicionado ao conjunto
        if dia in turno:
            conjPrdts.add(prdts[turno[3]][0]) 
    return conjPrdts
    
    
def lucroHora(turnos,prdts):
    somHoras=0#iniciando as variáveis com o elemento neutro da soma
    somLucro=0
    for turno in turnos:#para cada elemento em turnos o lucro e as horas são somadas
        somHoras+=turno[1]
        lucro= round(turno[2]*(prdts[turno[3]][2]-prdts[turno[3]][1]),6)
        somLucro+=lucro
    return somLucro/somHoras


prdts= {'L12v27': ['Lampada 12v E27', 2.15, 3.20], #definindo dicionário
        'L110v27': ['Lampada 110v E27', 1.93, 2.99],
        'LBv27': ['Lampada Bivolt E27', 2.15, 3.16],
        'LBv14': ['Lampada Bivolt E14', 1.92, 2.49],
        'L12v14': ['Lampada 12v E14', 1.99, 2.59],
       }
nPrdt=0 
diasSem= ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom'] #string para testar se o dia é válido
opc=5 #iniciando a opção como 5 para que ela seja diferente de 0 e o programa execute 
c=0
turnos=[]
turnosReverso=[]
while opc!=0:
    opc=int(input())#pega a opção
    if opc==1:
        novoTurno=[input(),int(input()),int(input()),input()] #opção 1 o programa recebe um novo turno e o adiciona à lista de turnos
        if novoTurno[0] in diasSem and novoTurno[3] in prdts.keys():
            turnos.append(novoTurno)
            novoTurno =list(reversed(novoTurno))#revertendo para ordenar na função 2
            turnosReverso.append(novoTurno)

            
    if opc==2:
        imprimeTurnos(turnosReverso)#opção 2 realiza a função imprme turnos
    if opc==3:
        lsPrdts=[]#opção 3 pede um dia, checa se é válido e, se for, realizaa função produtos dia
        dia=input()
        if dia in diasSem:
            lsPrdts=list(prdtsDia(turnos,dia,prdts))
            lsPrdts.sort()
            print(lsPrdts)
    if opc==4:
        print('%.4f' %(lucroHora(turnos, prdts)))#opção 4 imprime o lucro por hora
    